package com.quanxiaoha.xiaohashu.distributed.id.generator.constant;

/**
 * @author: 犬小哈
 * @date: 2024/4/13 23:23
 * @version: v1.0.0
 * @description: TODO
 **/
public interface ApiConstants {

    /**
     * 服务名称
     */
    String SERVICE_NAME = "xiaohashu-distributed-id-generator";
}
