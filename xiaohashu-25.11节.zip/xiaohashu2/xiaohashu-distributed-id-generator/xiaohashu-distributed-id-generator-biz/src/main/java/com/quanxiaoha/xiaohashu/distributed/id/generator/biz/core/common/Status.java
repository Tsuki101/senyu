package com.quanxiaoha.xiaohashu.distributed.id.generator.biz.core.common;

public enum  Status {
    SUCCESS,
    EXCEPTION
}
