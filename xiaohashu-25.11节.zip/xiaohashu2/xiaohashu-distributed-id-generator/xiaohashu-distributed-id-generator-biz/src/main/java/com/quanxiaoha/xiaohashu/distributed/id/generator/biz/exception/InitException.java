package com.quanxiaoha.xiaohashu.distributed.id.generator.biz.exception;

public class InitException extends Exception{
    public InitException(String msg) {
        super(msg);
    }
}
