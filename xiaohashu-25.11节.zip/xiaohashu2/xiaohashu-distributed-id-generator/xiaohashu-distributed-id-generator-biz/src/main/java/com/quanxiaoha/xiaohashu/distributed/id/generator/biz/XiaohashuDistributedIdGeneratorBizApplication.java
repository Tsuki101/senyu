package com.quanxiaoha.xiaohashu.distributed.id.generator.biz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XiaohashuDistributedIdGeneratorBizApplication {

    public static void main(String[] args) {
        SpringApplication.run(XiaohashuDistributedIdGeneratorBizApplication.class, args);
    }

}
