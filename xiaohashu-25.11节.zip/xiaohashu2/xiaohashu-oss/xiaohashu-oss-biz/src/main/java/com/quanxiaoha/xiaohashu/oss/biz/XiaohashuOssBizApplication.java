package com.quanxiaoha.xiaohashu.oss.biz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XiaohashuOssBizApplication {

    public static void main(String[] args) {
        SpringApplication.run(XiaohashuOssBizApplication.class, args);
    }

}
