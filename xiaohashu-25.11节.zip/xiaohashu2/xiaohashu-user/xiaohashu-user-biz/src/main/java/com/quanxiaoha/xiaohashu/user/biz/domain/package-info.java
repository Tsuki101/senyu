/**
 * @author: 犬小哈
 * @url: www.quanxiaoha.com
 * @date: 2024/5/7 15:52
 * @description: TODO
 **/
package com.quanxiaoha.xiaohashu.user.biz.domain;