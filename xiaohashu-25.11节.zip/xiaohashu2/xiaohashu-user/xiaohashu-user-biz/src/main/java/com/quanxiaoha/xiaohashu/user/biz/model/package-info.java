/**
 * @author: 犬小哈
 * @date: 2024/7/2 20:37
 * @version: v1.0.0
 * @description: TODO
 **/
package com.quanxiaoha.xiaohashu.user.biz.model;