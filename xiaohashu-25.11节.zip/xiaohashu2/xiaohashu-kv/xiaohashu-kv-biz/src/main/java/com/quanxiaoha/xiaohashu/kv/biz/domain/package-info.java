/**
 * @author: 犬小哈
 * @date: 2024/7/14 16:19
 * @version: v1.0.0
 * @description: TODO
 **/
package com.quanxiaoha.xiaohashu.kv.biz.domain;