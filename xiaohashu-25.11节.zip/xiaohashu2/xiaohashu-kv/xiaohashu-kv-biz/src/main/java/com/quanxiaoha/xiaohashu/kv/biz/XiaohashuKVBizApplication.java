package com.quanxiaoha.xiaohashu.kv.biz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XiaohashuKVBizApplication {

    public static void main(String[] args) {
        SpringApplication.run(XiaohashuKVBizApplication.class, args);
    }

}
