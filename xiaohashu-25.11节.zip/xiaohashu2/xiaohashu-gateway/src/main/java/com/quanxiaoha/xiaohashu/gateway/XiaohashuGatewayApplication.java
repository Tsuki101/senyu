package com.quanxiaoha.xiaohashu.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XiaohashuGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(XiaohashuGatewayApplication.class, args);
    }

}
